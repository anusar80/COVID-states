#%% Import modules
import os
import pandas as pd
import numpy as np
from matplotlib import pyplot as plt
import seaborn as sns
from sklearn.preprocessing import RobustScaler
import statsmodels.api as sm
import statsmodels.formula.api as smf
from sklearn.linear_model import Ridge
from sklearn.linear_model import RidgeCV
from statsmodels.api import Logit
from pingouin import corr, partial_corr
import xlsxwriter
from scipy.spatial.distance import squareform
from scipy.cluster.hierarchy import dendrogram, linkage
from pandas.plotting import register_matplotlib_converters
from sklearn.model_selection import train_test_split
from sklearn.model_selection import LeaveOneOut
from matplotlib import dates as mdates
from sklearn.decomposition import PCA
import plotly.graph_objects as go
import warnings
import time
from datetime import date, datetime
from matplotlib.dates import DateFormatter
from statsmodels.tools.sm_exceptions import ConvergenceWarning
warnings.simplefilter('ignore', ConvergenceWarning)
sns.set()
#%% To fix the date fuck-ups
old_epoch = '0000-12-31T00:00:00'
new_epoch = '1970-01-01T00:00:00'
mdates.set_epoch(old_epoch)
plt.rcParams['date.epoch'] = '000-12-31'
plt.rcParams['axes.facecolor'] = 'w'
plt.style.use('seaborn')
register_matplotlib_converters()
#%% Clock utility function
def TicTocGenerator():
    ti = 0
    tf = time.time()
    while True:
        ti = tf
        tf = time.time()
        yield tf - ti
TicToc = TicTocGenerator()
def toc(tempBool=True):
    tempTimeInterval = next(TicToc)
    if tempBool:
        print("Elapsed time: %f seconds.\n" % tempTimeInterval)
def tic():
    toc(False)

def abline(slope, intercept):
    """Plot a line from slope and intercept"""
    axes = plt.gca()
    x_vals = np.array(axes.get_xlim())
    y_vals = intercept + slope * x_vals
    plt.plot(x_vals, y_vals, ':')

def check_symmetric(a, tol=1e-8):
    return np.all(np.abs(a-a.T) < tol)

def label_point(x, y, val, ax):
    a = pd.concat({'x': x, 'y': y, 'val': val}, axis=1)
    for i, point in a.iterrows():
        ax.text(point['x']+.005, point['y'], str(point['val']))

Y = 2000 # dummy leap year to allow input X-02-29 (leap day)
seasons = [('Winter', (date(Y,  1,  1),  date(Y,  3, 20))),
           ('Spring', (date(Y,  3, 21),  date(Y,  6, 20))),
           ('Summer', (date(Y,  6, 21),  date(Y,  9, 22))),
           ('Fall', (date(Y,  9, 23),  date(Y, 12, 20))),
           ('Winter', (date(Y, 12, 21),  date(Y, 12, 31)))]

def get_season(now):
    if isinstance(now, datetime):
        now = now.date()
    now = now.replace(year=Y)
    return next(season for season, (start, end) in seasons
                if start <= now <= end)

#%% Get Covid-19 data by state
os.chdir('/Users/anusarfarooqui/Docs/Matlab')
esri = pd.read_excel('Definitive_Healthcare_USA_Hospital_Beds.xlsx')
state_fips = pd.read_excel('state_fips.xlsx')
Capacity = pd.DataFrame({'Beds': esri.NUM_LICENSED_BEDS.groupby(esri.STATE_FIPS).sum(),
                         'Staffed': esri.NUM_STAFFED_BEDS.groupby(esri.STATE_FIPS).sum(),
                         'ICU': esri.NUM_ICU_BEDS.groupby(esri.STATE_FIPS).sum()})
Capacity['FIPS'] = Capacity.index
Capacity = state_fips.merge(Capacity, how='inner', left_on='FIPS', right_on='FIPS')

url = 'https://covidtracking.com/data/download/all-states-history.csv'
covid_tracking = pd.read_csv(url, header=0, low_memory=False, usecols=['date', 'state', 'hospitalized',
                                                                       'hospitalizedCumulative', 'hospitalizedCurrently',
                                                                       'hospitalizedIncrease', 'inIcuCumulative', 'inIcuCurrently',
                                                                       'death', 'deathIncrease', 'deathConfirmed', 'deathProbable'])
covid_tracking['date'] = pd.to_datetime(covid_tracking['date'])
dates = covid_tracking['date'].unique()
states = Capacity['Code'].values
#%% Get behavior
os.chdir('/Users/anusarfarooqui/Docs/Matlab/COVID')
pop = pd.read_excel('states_population.xlsx')
Age = pd.read_excel('Age.xlsx')
avoid_contact = pd.read_excel('avoid_contact.xlsx')
avoid_crowds = pd.read_excel('avoid_crowds.xlsx')
cafe_bar_res = pd.read_excel('cafe_bar_restaurant.xlsx')
church = pd.read_excel('church.xlsx')
disinfect_surfaces = pd.read_excel('disinfect_surfaces.xlsx')
doctor = pd.read_excel('doctor.xlsx')
event = pd.read_excel('event.xlsx')
gym = pd.read_excel('gym.xlsx')
mask = pd.read_excel('mask.xlsx')
mass_transit = pd.read_excel('mass_transit.xlsx')
sdi = pd.read_excel('SDI.xlsx')
sdi['Fall'] = sdi['Autumn']
sdi=sdi.drop('Autumn', axis=1)
visit_friend = pd.read_excel('visit_friend.xlsx')
wash_hands = pd.read_excel('wash_hands.xlsx')
work = pd.read_excel('work.xlsx')

#%% Create panel data
hospitalized = np.zeros((len(dates), len(states)))
hospitalized_per_100k = np.zeros((len(dates), len(states)))
beds_occupied = np.zeros((len(dates), len(states)))
staffed_occupied = np.zeros((len(dates), len(states)))
ICU_ratio = np.zeros((len(dates), len(states)))

for i in range(len(dates)):
    for j in range(len(states)):
        idx = np.logical_and(covid_tracking['date']==dates[i], covid_tracking['state']==states[j])
        if len(covid_tracking[idx]['hospitalizedCurrently'])==0:
            hospitalized[i, j] = np.nan
            hospitalized_per_100k[i, j] = np.nan
            beds_occupied[i, j] = np.nan
            staffed_occupied[i, j] = np.nan
            ICU_ratio[i, j] = np.nan
        else:
            hospitalized[i, j] = covid_tracking[idx]['hospitalizedCurrently']
            hospitalized_per_100k[i, j] = 100000 * hospitalized[i, j] / pop[pop['State']==states[0]]['Population']
            beds_occupied[i, j] = hospitalized[i, j] / Capacity[Capacity['Code']==states[j]]['Beds']
            staffed_occupied[i, j] = hospitalized[i, j] / Capacity[Capacity['Code']==states[j]]['Staffed']
            ICU_ratio[i, j] = hospitalized[i, j] / Capacity[Capacity['Code']==states[j]]['ICU']

Hospitalized = pd.DataFrame(data=hospitalized, index=dates, columns=states)
Hospitalized_per_100k = pd.DataFrame(data=hospitalized_per_100k, index=dates, columns=states)
Beds_Occupied = pd.DataFrame(data=beds_occupied, index=dates, columns=states)
Staffed_Occupied = pd.DataFrame(data=staffed_occupied, index=dates, columns=states)
ICU_Ratio = pd.DataFrame(data=ICU_ratio, index=dates, columns=states)
#%% Get burden in long form
w = np.chararray(len(Hospitalized_per_100k), itemsize=6)
for i in range(len(Hospitalized_per_100k)):
    w[i] = get_season(Hospitalized_per_100k.index[i])
Hospitalized_per_100k['Season'] = w.astype('str')
for_long_form = Hospitalized_per_100k.groupby(Hospitalized_per_100k.Season).mean().T
for_long_form['State'] = for_long_form.index.to_numpy()
long_form = for_long_form.melt(id_vars='State', value_vars=['Spring', 'Summer', 'Fall'], var_name='Season', value_name='Hospitalization_per_100k')
Burden = long_form.set_index(pd.MultiIndex.from_frame(long_form.drop('Hospitalization_per_100k', axis=1)))
#%% Proximate causation: masks
Mask = mask.melt(id_vars='State', value_vars=['Spring', 'Summer', 'Fall'], var_name='Season', value_name='Mask')
Mask = Mask.set_index(pd.MultiIndex.from_frame(Mask.drop('Mask', axis=1)))
Mask = Mask.drop(['State', 'Season'], axis=1)
Mask_vs_Burden = Mask.merge(Burden, how='inner', left_index=True, right_index=True)

plt.figure(dpi=400)
sns.scatterplot(x='Mask', y='Hospitalization_per_100k', hue='Season', data=Mask_vs_Burden)
plt.title('Mask wearing is weakly but positively associated with COVID-19 burdens')
plt.savefig('masks_vs_burden.png')
plt.show()

model = smf.mixedlm('Hospitalization_per_100k~Mask', groups='Season', missing='drop', data=Mask_vs_Burden).fit()
print(model.summary())
model = smf.ols('Hospitalization_per_100k~Season+Mask', data=Mask_vs_Burden, missing='drop').fit()
print(model.summary())
#%% Proximate causation: sdi
SDI = sdi.melt(id_vars='State', value_vars=['Spring', 'Summer', 'Fall'], var_name='Season', value_name='SDI')
SDI = SDI.set_index(pd.MultiIndex.from_frame(SDI.drop('SDI', axis=1)))
SDI = SDI.drop(['State', 'Season'], axis=1)
SDI_vs_Burden = SDI.merge(Burden, how='inner', left_index=True, right_index=True)

plt.figure(dpi=400)
sns.scatterplot(x='SDI', y='Hospitalization_per_100k', hue='Season', data=SDI_vs_Burden)
plt.title('Social distancing is weakly but positively associated with COVID-19 burdens')
plt.savefig('SDI_vs_burden.png')
plt.show()

model = smf.mixedlm('Hospitalization_per_100k~SDI', groups='Season', missing='drop', data=SDI_vs_Burden).fit()
print(model.summary())
model = smf.ols('Hospitalization_per_100k~Season+SDI', data=SDI_vs_Burden, missing='drop').fit()
print(model.summary())
#%% General model
df_list= [avoid_crowds, cafe_bar_res, church, disinfect_surfaces,
          doctor, event, gym, mask, mass_transit, visit_friend, wash_hands, work] # sdi and avoid_contact skipped
labels = ['avoid_crowds', 'cafe_bar_res', 'church', 'disinfect_surfaces',
          'doctor', 'event', 'gym', 'mask', 'mass_transit', 'visit_friend', 'wash_hands', 'work']

formula = 'Hospitalization_per_100k~1'
for i in range(len(df_list)):
    df = df_list[i].melt(id_vars='State', value_vars=['Spring', 'Summer', 'Fall'], var_name='Season', value_name=labels[i])
    df = df.set_index(pd.MultiIndex.from_frame(df.drop(labels[i], axis=1)))
    df = df.drop(['State', 'Season'], axis=1)
    Burden = df.merge(Burden, how='inner', left_index=True, right_index=True)
    del df
    formula = formula + ' + ' + labels[i]


model = smf.mixedlm(formula, groups='Season', missing='drop', data=Burden).fit()
print(model.summary())
random_effects = pd.DataFrame.from_dict(model.random_effects).transpose()
print(random_effects)
formula = formula+' + Season'
model = smf.ols(formula, data=Burden, missing='drop').fit()
print(model.summary())

#%% Individual estimates
# adjust for age
age_adjustment = pd.DataFrame({'State': Age['State'], 'Spring': Age['More Than 70 Years'], 'Summer': Age['More Than 70 Years'], 'Fall': Age['More Than 70 Years']})
age_adjustment = age_adjustment.melt(id_vars='State', value_vars=['Spring', 'Summer', 'Fall'], var_name='Season', value_name='Age')
age_adjustment = age_adjustment.set_index(pd.MultiIndex.from_frame(age_adjustment.drop('Age', axis=1)))
age_adjustment = age_adjustment.drop(['State', 'Season'], axis=1)
# Reconstruct Burden
w = np.chararray(len(Hospitalized_per_100k), itemsize=6)
for i in range(len(Hospitalized_per_100k)):
    w[i] = get_season(Hospitalized_per_100k.index[i])
Hospitalized_per_100k['Season'] = w.astype('str')
for_long_form = Hospitalized_per_100k.groupby(Hospitalized_per_100k.Season).mean().T
for_long_form['State'] = for_long_form.index.to_numpy()
long_form = for_long_form.melt(id_vars='State', value_vars=['Spring', 'Summer', 'Fall'], var_name='Season', value_name='Hospitalization_per_100k')
Burden = long_form.set_index(pd.MultiIndex.from_frame(long_form.drop('Hospitalization_per_100k', axis=1)))
Burden = age_adjustment.merge(Burden, how='inner', left_index=True, right_index=True)
# Reset list of features
df_list= [sdi, avoid_contact, avoid_crowds, cafe_bar_res, church, disinfect_surfaces,
          doctor, event, gym, mask, mass_transit, visit_friend, wash_hands, work]
labels = ['sdi', 'avoid_contact', 'avoid_crowds', 'cafe_bar_res', 'church', 'disinfect_surfaces',
          'doctor', 'event', 'gym', 'mask', 'mass_transit', 'visit_friend', 'wash_hands', 'work']
for i in range(len(df_list)):
    df = df_list[i].melt(id_vars='State', value_vars=['Spring', 'Summer', 'Fall'], var_name='Season', value_name=labels[i])
    df = df.set_index(pd.MultiIndex.from_frame(df.drop(labels[i], axis=1)))
    df = df.drop(['State', 'Season'], axis=1)
    Burden = df.merge(Burden, how='inner', left_index=True, right_index=True)

#%% OLS estimates
b = np.zeros(len(labels))
se = np.zeros(len(labels))
pval = np.zeros(len(labels))
for i in range(len(labels)):
    formula = 'Hospitalization_per_100k ~ ' + labels[i]
    model = smf.ols(formula, data=Burden).fit()
    b[i] = model.params[-1]
    se[i] = model.bse[-1]
    pval[i] = model.pvalues[-1]
ols_results = pd.DataFrame({'Slope': b, 'StdErr': se, 'P': pval}, index=labels)

b = np.zeros(len(labels))
se = np.zeros(len(labels))
pval = np.zeros(len(labels))
for i in range(len(labels)):
    formula = 'Hospitalization_per_100k ~ Season + Age + ' + labels[i]
    model = smf.ols(formula, data=Burden).fit()
    b[i] = model.params[-1]
    se[i] = model.bse[-1]
    pval[i] = model.pvalues[-1]
ols_results_season_fe = pd.DataFrame({'Slope': b, 'StdErr': se, 'P': pval}, index=labels)

plt.figure(dpi=400)
plt.errorbar(x=ols_results.Slope, y=ols_results.index, xerr=ols_results.StdErr, fmt='bo')
plt.errorbar(x=ols_results_season_fe.Slope, y=ols_results_season_fe.index, xerr=ols_results_season_fe.StdErr, fmt='rd')
plt.legend(['No controls', 'Season and age fixed effects'])
plt.vlines(0, 0, len(labels), colors='k')
plt.xlabel('OLS slope coefficients and std errors')
plt.title('Response is Covid hospitalizations per 100k (Source: CovidTracking, CovidStates)')
plt.savefig('OLS_estimates.png')
plt.show()
#%% Quantile regression estimates
b = np.zeros(len(labels))
se = np.zeros(len(labels))
pval = np.zeros(len(labels))
for i in range(len(labels)):
    formula = 'Hospitalization_per_100k ~ ' + labels[i]
    model = smf.quantreg(formula, data=Burden).fit()
    b[i] = model.params[-1]
    se[i] = model.bse[-1]
    pval[i] = model.pvalues[-1]
qReg_results = pd.DataFrame({'Slope': b, 'StdErr': se, 'P': pval}, index=labels)

b = np.zeros(len(labels))
se = np.zeros(len(labels))
pval = np.zeros(len(labels))
for i in range(len(labels)):
    formula = 'Hospitalization_per_100k ~ Season + Age + ' + labels[i]
    model = smf.quantreg(formula, data=Burden).fit()
    b[i] = model.params[-1]
    se[i] = model.bse[-1]
    pval[i] = model.pvalues[-1]
qReg_results_season_fe = pd.DataFrame({'Slope': b, 'StdErr': se, 'P': pval}, index=labels)

plt.figure(dpi=400)
plt.errorbar(x=qReg_results.Slope, y=qReg_results.index, xerr=qReg_results.StdErr, fmt='bo')
plt.errorbar(x=qReg_results_season_fe.Slope, y=qReg_results_season_fe.index, xerr=qReg_results_season_fe.StdErr, fmt='rd')
plt.legend(['No controls', 'Season and age fixed effects'])
plt.vlines(0, 0, len(labels), colors='k')
plt.xlabel('Quantile regression slope coefficients and std errors')
plt.title('Response is Covid hospitalizations per 100k (Source: CovidTracking, CovidStates)')
plt.savefig('qReg_estimates.png')
plt.show()
#%% Plot them all
for i in range(len(labels)):
    plt.figure(dpi=400)
    sns.scatterplot(x=labels[i], y='Hospitalization_per_100k', hue='Season', data=Burden)
    plt.savefig('scatter_' + labels[i] + '.png')
    plt.show()

for i in range(len(labels)):
    plt.figure(dpi=400)
    sns.boxplot(x='Season', y=labels[i], data=Burden, palette='coolwarm')
    plt.xlabel(None)
    plt.title('Seasonal pattern of behavior')
    plt.savefig('behavior_' + labels[i] + '.png')
    plt.show()


model = smf.mixedlm('Hospitalization_per_100k ~ sdi', groups='Season', missing='drop', data=Burden).fit()
print(model.summary())
model = smf.mixedlm('Hospitalization_per_100k ~ sdi + Season', groups='State', missing='drop', data=Burden).fit()
print(model.summary())





#%% Govt response tracker
url = 'https://github.com/OxCGRT/covid-policy-tracker/raw/master/data/OxCGRT_latest.csv'
tracker = pd.read_csv(url, low_memory=False)
usa = tracker[tracker.CountryCode=='USA']
xoxo = pd.to_datetime(usa.Date.astype('str'), format='%Y%m%d')
usa['Date'] = xoxo
del tracker
del xoxo
StateSI = usa.StringencyIndex.groupby([usa.Date, usa.RegionCode]).mean().unstack()
StateSI.fillna(method='ffill', inplace=True)
#%% Stringency and hospitalizations
states = np.chararray(len(StateSI.columns), itemsize=2)
for i in range(len(StateSI.columns)):
    states[i] = np.chararray.split(StateSI.columns.to_numpy(dtype='str'), '_')[i][1]
states = states.astype('str')
Stringency = pd.DataFrame(data=StateSI.to_numpy(), index=StateSI.index, columns=states)
# Stringency['Mean'] = np.nanmean(Stringency.to_numpy(), axis=1)
Stringency['Date'] = Stringency.index
SI = pd.melt(Stringency, id_vars='Date', value_vars=states[:-1], var_name='State', value_name='Stringency') #np.append(states[:-1], 'Mean')
df_SI = pd.DataFrame(data=SI.Stringency.to_numpy(),
                     index=pd.MultiIndex.from_arrays(np.array((SI.Date, SI.State)), names=['Date', 'State']),
                     columns=['Stringency'])

states = Capacity['Code'].values
Beds_Occupied = pd.DataFrame(data=beds_occupied, index=dates, columns=states)
# Beds_Occupied['Mean'] = np.nanmean(Beds_Occupied.to_numpy(), axis=1)
Beds_Occupied['Date'] = Beds_Occupied.index
Occupied = pd.melt(Beds_Occupied, id_vars='Date', value_vars=states[:-1], var_name='State', value_name='Occupancy')
df_occupy = pd.DataFrame(data=Occupied.Occupancy.to_numpy(),
                         index=pd.MultiIndex.from_arrays(np.array((Occupied.Date, Occupied.State)), names=['Date', 'State']),
                         columns=['Occupancy'])

df = df_SI.merge(df_occupy, how='inner', left_index=True, right_index=True, validate='one_to_one')
df = pd.DataFrame({'Stringency': df['Stringency'], 'Occupancy': df['Occupancy'],
                   'Date': df.index.to_frame().Date, 'State': df.index.to_frame().State})
#%% Mixed linear models
df['MeanOccupancy'] = np.tile(df.Occupancy.groupby(df.Date).mean().to_numpy(), len(df.State.unique()))
df['MeanStringency'] = np.tile(df.Stringency.groupby(df.Date).mean().to_numpy(), len(df.State.unique()))
model = smf.mixedlm('Occupancy~MeanOccupancy+Stringency', groups='State', data=df, missing='drop').fit()
print(model.summary())
random_effects = pd.DataFrame.from_dict(model.random_effects).transpose()
print(random_effects)

model = smf.mixedlm('Occupancy~MeanOccupancy', groups='State', re_formula='~Stringency', data=df, missing='drop').fit()
print(model.summary())
random_effects = pd.DataFrame.from_dict(model.random_effects).transpose()
print(random_effects)
plt.figure(dpi=500)
for i in range(len(random_effects)):
    abline(random_effects.Stringency[i], random_effects.State[i])
plt.show()
#
plt.figure()
sns.lineplot(x=df.Occupancy.groupby(df.Date).mean().index, y=df.Occupancy.groupby(df.Date).mean().values)
plt.show()
plt.figure()
sns.lineplot(x=df.Stringency.groupby(df.Date).mean().index, y=df.Stringency.groupby(df.Date).mean().values)
plt.show()

plt.figure(dpi=400)
sns.regplot(x='Stringency', y='Occupancy', data=df)
plt.show()

Str = df.Stringency.groupby(df.State).mean().index.to_numpy()
plt.figure(dpi=400)
sns.regplot(x=df.Stringency.groupby(df.State).mean().to_numpy(), y=df.Occupancy.groupby(df.State).mean().to_numpy())
label_point(df.Stringency.groupby(df.State).mean(),
            df.Occupancy.groupby(df.State).mean(),
            Str,
            plt.gca())
plt.show()

#%% Which cutoff in age predicts covid burdens?
df = Age.merge(Hospitalized.iloc[0], how='inner', left_on='State', right_index=True)
df = df.merge(pop, how='inner', left_on='State', right_on='State')
df['HospPerMillion'] = 1000000 * df.iloc[:, -2] / df['Population']
rho = np.zeros((17, 2))
for i in range(17):
    rho[i, 0] = corr(x=df.iloc[:, -1], y=df.iloc[:, 1+i], method='spearman')['r'].values
    rho[i, 1] = corr(x=df.iloc[:, -1], y=df.iloc[:, 1+i], method='spearman')['p-val'].values
rho = pd.DataFrame(data=rho, index=df.columns[1:-3], columns=['r', 'P'])
print(rho)

plt.figure()
sns.set(palette='coolwarm')
for i in range(17):
    sns.scatterplot(x=df.iloc[:, 1+i], y=df.iloc[:, -1])
plt.ylabel('Hospitalization per million')
plt.xlabel('percent of state population aged (color) or above')
plt.title('Covid burden by state stratified by age')
plt.show()

plt.figure()
sns.regplot(x=df.iloc[:, 14], y=df.iloc[:, -1])
plt.show()